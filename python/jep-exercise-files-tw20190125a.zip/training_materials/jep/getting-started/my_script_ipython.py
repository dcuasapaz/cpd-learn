import platform

print('Hello from "Just Enough" IPython')
print('Python version: ' + platform.python_version())
