#!/usr/bin/env python3
import platform

print('Hello from "Just Enough" Python')
print('Python version: ' + platform.python_version())
