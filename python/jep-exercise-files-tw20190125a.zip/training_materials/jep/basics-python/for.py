#!/usr/bin/python3
# Copyright 2019 Cloudera, Inc.
# Not to be reproduced or shared without prior written consent from Cloudera.

# These are the statements used in 
# Hands-On Exercise: Controlling Program Flow

first_name = 'Sophie'
for letter in first_name:
    print(letter)

for counter in range(10):
    print(counter)


